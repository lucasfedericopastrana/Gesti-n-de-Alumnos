// var a=1;
// var b=2;
// var nombre="Mauri";
// var apellido="Sambre";
//
// var nombreCompleto=nombre+" "+apellido;
//
// alert("Holi "+nombreCompleto);
